<table border="0" bgcolor="#024b8b" cellpadding="0" cellspacing="0" width="100%">
    <tr>
        <td align="center" valign="top">
            <!-- FLEXIBLE CONTAINER // -->
            <table border="0" cellpadding="30" cellspacing="0" width="670"
                class="flexibleContainer">
                <tr>
                <td valign="top" width="670" class="flexibleContainerCell">
                    <!-- CONTENT TABLE // -->
                    <table align="left" border="0" cellpadding="0" cellspacing="0"
                        width="100%">
                        <tr>
                            <td align="left" valign="top" class="flexibleContainerBox">
                            <table border="0" cellpadding="0" cellspacing="0"
                                width="100%" style="max-width:100%;">
                                <tr>
                                    <td align="left" class="textContent">
                                        <h3 style="color:#FFFFFF;line-height:normal;font-family:Helvetica,Arial,sans-serif;font-size:20px;font-weight:bold;margin-top:0;margin-bottom:14px;text-align:left;">
                                        Our Services
                                        </h3>
                                        <div style="text-align:left;font-family:Helvetica,Arial,sans-serif;font-size:14px;margin-bottom:0;color:#FFFFFF;line-height:135%;">
                                        <a target="_blank" href="#"
                                            style="color:#fff;text-decoration:none;">Air Conditioning</a> | <a
                                            target="_blank" href="#"
                                            style="text-decoration:none;color:#fff;">Carpentry</a> | <a
                                            target="_blank" href="#"
                                            style="text-decoration:none;color:#fff;">Carpentry</a> | <a
                                            target="_blank" href="#"
                                            style="text-decoration:none;color:#fff;">Drywall</a> | <a
                                            target="_blank" href="#"
                                            style="text-decoration:none;color:#fff;">Painting</a> | <a
                                            target="_blank" href="#"
                                            style="text-decoration:none;color:#fff;">Electrical</a> | <a
                                            target="_blank" href="#"
                                            style="text-decoration:none;color:#fff;">Plumbing</a> | <a
                                            target="_blank" href="#"
                                            style="text-decoration:none;color:#fff;">Remodeling</a> | <a
                                            target="_blank" href="#"
                                            style="text-decoration:none;color:#fff;">Roofing</a> | <a
                                            target="_blank" href="#"
                                            style="text-decoration:none;color:#fff;">Pest Control</a> | <a
                                            target="_blank" href="#"
                                            style="text-decoration:none;color:#fff;">Handyman</a>
                                            
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="border-bottom:1px solid #828282;">
                                        &nbsp;
                                    </td>
                                </tr>
                                <tr>
                                    <td align="left" style="padding-top:10px;">
                                                <div style="text-align:left;font-family:Helvetica,Arial,sans-serif;font-size:20px;font-weight:bold;margin-bottom:10px;color:#FFFFFF;line-height:150%;">
                                                    Follow Us
                                                </div>
                                                <div style="display: flex;">
                                                <a target="_blank" href="#">
                                                    <img src="https://i.ibb.co/f2CxNxh/icons8-facebook-50.png" alt="icons8-facebook-50" border="0" style="width:24px; padding-right:5px;">
                                                </a>
                                                <a target="_blank" href="#">
                                                    <img src="https://i.ibb.co/8DLhwTr/icons8-linkedin-circled-50.png" alt="icons8-linkedin-circled-50" border="0" style="width:24px; padding-right:5px;">
                                                </a>
                                                <a target="_blank" href="#">
                                                    <img src="https://i.ibb.co/yRZ757b/icons8-twitter-circled-50.png" alt="icons8-twitter-circled-50" border="0" style="width:24px; padding-right:5px;">
                                                </a>
                                                <a target="_blank" href="#">
                                                    <img src="https://i.ibb.co/qY3TmnQ/icons8-instagram-circle-60.png" alt="icons8-instagram-circle-60" border="0" style="width:24px; padding-right:5px;">
                                                </a>
                                                </div>
                                            </td>
                                </tr>
                                <tr>
                                    <td>
                                        <table border="0" cellpadding="0"
                                        cellspacing="0" width="100%">
                                        <tr>
                                            
                                        </tr>
                                        </table>
                                    </td>
                                </tr>
                            </table>
                            </td>
                        </tr>
                        <tr>
                            <td style="border-bottom:1px solid #828282;">
                            &nbsp;
                            </td>
                        </tr> 
                    </table>
                    <!-- // CONTENT TABLE -->
                </td>
                </tr>
            </table>
            <!-- // FLEXIBLE CONTAINER -->
        </td>
    </tr>
    </table>

<!-- EMAIL FOOTER // -->  
 <table bgcolor="#024b8b" border="0" cellpadding="0" cellspacing="0" width="100%" id="emailFooter" style="background-color:#024b8b;">
    <!-- FOOTER ROW // -->                    
    <tr>
    <td align="center" valign="top">
        <!-- CENTERING TABLE // -->
        <table border="0" cellpadding="0" cellspacing="0" width="100%">
            <tr>
                <td align="center" valign="top">
                <!-- FLEXIBLE CONTAINER // -->
                <table border="0" cellpadding="0" cellspacing="0" width="670"
                    class="flexibleContainer">
                    <tr>
                        <td align="center" valign="top" width="670"
                            class="flexibleContainerCell">
                            <table border="0" cellpadding="0" cellspacing="0" width="100%">
                            <tr>
                                <td valign="top" bgcolor="#024b8b">
                                    <div style="font-family:Helvetica,Arial,sans-serif;font-size:12px;color:#fff;text-align:left;line-height:150%;margin-bottom:15px; padding-left:30px; padding-right:30px;">
                                        <div>You received this email because you recently requested from us and we wanted to share your move details. Please give us some more time to review everything so we can provide the most accurate service. <a
                                        href="{{isset($user) && is_object($user)?route('unsubscribers.store',$user->member_id):'#' }}"
                                        target="_blank"
                                        style="text-decoration:none;color:#fff;"><span
                                        style="color:#fff;">Unsubscribe</span></a>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            </table>
                        </td>
                    </tr>
                </table>
                <!-- // FLEXIBLE CONTAINER -->
                </td>
            </tr>
        </table>
        <!-- // CENTERING TABLE -->
    </td>
    </tr>
</table>
<!-- // END -->