<table border="0" cellpadding="0" cellspacing="0" width="100%" style="color:#FFFFFF;" bgcolor="#fff">
    <tr>
        <td align="center" valign="top">                                   
        <table border="0" cellpadding="0" cellspacing="0" width="670"
            class="flexibleContainer">
            <tr>
                <td align="center" valign="top" width="670"
                    class="flexibleContainerCell"> 
                    <table border="0" cellpadding="1" cellspacing="0" width="100%">
                    <tr>
                        <td align="center" valign="middle" class="textContent" style="padding:10px;">
                            <a href="#"><img src="http://contractoruniverse.com/wp-content/uploads/2023/04/logo-1-1.png"
                                alt="Logo" border="0"
                                style="display:inline-block; max-width:300px; width:300px;"></a>
                            
                        </td>
                    </tr>
                    </table>
                    <!-- // CONTENT TABLE -->
                </td>
            </tr>
        </table>
        <!-- // FLEXIBLE CONTAINER -->
        </td>
    </tr>
</table>
<!-- // CENTERING TABLE -->